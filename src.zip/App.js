import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store';

import Home from './pages/Home';
import TravelPlannerPage from './pages/travel-planner/TravelMain';
import Step1 from './pages/travel-planner/destination/Step1';
import Step2Page from './pages/travel-planner/destination/Step2';
import Step3 from './pages/travel-planner/destination/Step3';
import Step4 from './pages/travel-planner/destination/Step4';
import Step5 from './pages/travel-planner/destination/Step5';
import MyPage from './pages/mypage/MyPage';
import AttractionsPage from './pages/attractions/Attractions';
import CommunityPage from './pages/community/Community';
import WritePage from './pages/community/write/Page';
import LoginPage from './pages/login/Login';
import SignupPage from './pages/signup/Signup';
import AdminPage from './pages/admin/Page';
import AIPlannerPage from "./pages/travel-planner/destination/AIPlannerPage";
import {AIPlannerContent} from "./components/travel-planner/AIPlannerContent";
import { PrivateRoute } from './components/PrivateRoute';

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route
            path="/mypage"
            element={
              <PrivateRoute>
                <MyPage />
              </PrivateRoute>
            }
          />
          <Route path="/community" element={<CommunityPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/attraction-content" element={<AttractionsPage />} />
          <Route path="/travel-planner" element={<TravelPlannerPage />} />
          <Route path="/ai-planner/:destination" element={<AIPlannerPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/community/write" element={<WritePage />} />
          <Route
            path="/travel-planner/:destination/step1"
            element={<Step1 />}
          />
          <Route
            path="/travel-planner/:destination/step2"
            element={<Step2Page />}
          />
          <Route
            path="/travel-planner/:destination/step3"
            element={<Step3 />}
          />
          <Route
            path="/travel-planner/:destination/step4"
            element={<Step4 />}
          />
          <Route
            path="/travel-planner/:destination/step5"
            element={<Step5 />}
          />
          <Route path="/not-found" element={<div>404 Not Found</div>} />{' '}
          {/* 임시 404 페이지 */}
        </Routes>
      </BrowserRouter>
    </Provider>
  );
}

export default App;
